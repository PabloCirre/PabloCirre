<?php
/**
 * Verne Games - Portfolio Oficial
 */

$page_title = "Verne Games | Estudio Indie Granada | Terror y Narrativa";
$page_description = "Verne Games - El estudio indie más pequeño. Creadores de La Semana del Cometa. Terror, pixel art y narrativas inmersivas desde Granada.";
$page_keywords = "verne games, indie dev granada, la semana del cometa, shadow over innsmouth, survival horror, pablo cirre";

include '../../Components/header.php';
?>

<!-- Hero Section -->
<section class="hero-section" style="padding: 100px 0;">
    <h1 class="hero-title" style="font-size: 4.5rem; line-height: 1;">
        Verne Games.<br>
        <span style="color: var(--accent-color);">Creatividad</span> sobre presupuesto.
    </h1>
    <p class="hero-subtitle" style="font-size: 1.5rem; margin-top: 30px; opacity: 0.9;">
        Somos el estudio indie más pequeño. Creamos mundos desde <strong
            style="color: var(--text-color);">Granada</strong> con carácter andaluz.
        Especialistas en atmósferas low-poly y narrativas de terror.
    </p>
</section>

<!-- Team Grid -->
<h2 class="section-title">El Equipo</h2>
<div class="metrics-grid" style="grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 100px;">
    <!-- Pablo Cirre -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">DIRECTOR</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Pablo Cirre</div>
            <div class="metric-desc">Dirección y Producción</div>
        </div>
    </div>
    <!-- Julen -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">ART DIR</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Julen</div>
            <div class="metric-desc">Modelado 3D & Iluminación</div>
        </div>
    </div>
    <!-- Lucas -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">NARRATIVE</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Lucas</div>
            <div class="metric-desc">Diálogos e Historia</div>
        </div>
    </div>
    <!-- Christian -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">GAMEPLAY</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Christian</div>
            <div class="metric-desc">Mecánicas & IA</div>
        </div>
    </div>
    <!-- Alex -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">SYSTEMS</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Alex</div>
            <div class="metric-desc">UI & Arquitectura</div>
        </div>
    </div>
    <!-- Mery -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">ENGINEERING</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Mery</div>
            <div class="metric-desc">Programación & UX</div>
        </div>
    </div>
    <!-- Juan -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">ARTIST</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Juan</div>
            <div class="metric-desc">Modelado & Estética</div>
        </div>
    </div>
    <!-- Alberto -->
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">MARKETING</span>
            <div class="light on"></div>
        </div>
        <div class="panel-content">
            <div class="metric-value" style="font-size: 1.5rem;">Alberto</div>
            <div class="metric-desc">Organización</div>
        </div>
    </div>
</div>

<!-- Projects Section -->
<h2 class="section-title">Proyectos Destacados</h2>
<div class="projects-grid" style="grid-template-columns: repeat(2, 1fr); margin-bottom: 100px;">

    <!-- La Semana del Cometa -->
    <div class="project-card">
        <div class="panel-header">
            <span class="panel-label available" style="color: var(--accent-color);">BETA DISPONIBLE</span>
            <div class="light on"></div>
        </div>
        <h3 class="project-title">La Semana del Cometa</h3>
        <p class="project-desc">
            Tras el paso del Cometa Halley, una niebla misteriosa aísla el "Centro Comercial Flamingo".
            Inspirado en el cine de serie B de los 80s, Alex debe sobrevivir a una pesadilla de neón.
            <br><br>
            <strong>Género:</strong> Videoaventura / Survival Horror
        </p>

        <div class="project-metrics">
            <div class="p-metric">
                <span class="pm-label">Mecánica</span>
                <span class="pm-value">Cámara Cine</span>
            </div>
            <div class="p-metric">
                <span class="pm-label">Recurso</span>
                <span class="pm-value">Gasolina</span>
            </div>
            <div class="p-metric">
                <span class="pm-label">Acción</span>
                <span class="pm-value">Sigilo</span>
            </div>
        </div>

        <a href="https://vernegames.itch.io/" class="btn-primary" style="margin-top: 20px;">Jugar Demo (Itch.io)</a>
    </div>

    <!-- Shadow Over Innsmouth -->
    <div class="project-card" style="opacity: 0.8;">
        <div class="panel-header">
            <span class="panel-label">EN DESARROLLO</span>
            <div class="light on dimmed"></div>
        </div>
        <h3 class="project-title">Shadow Over Innsmouth</h3>
        <p class="project-desc">
            Una experiencia inmersiva basada en la atmósfera y el terror lovecraftiano.
            Investiga los secretos profundos de una ciudad costera maldita.
            <br><br>
            <strong>Estilo:</strong> Low-poly Atmosférico
        </p>

        <div class="project-metrics">
            <div class="p-metric">
                <span class="pm-label">Atmósfera</span>
                <span class="pm-value">Terror</span>
            </div>
            <div class="p-metric">
                <span class="pm-label">Estado</span>
                <span class="pm-value">Dev</span>
            </div>
        </div>
    </div>
</div>

<!-- Devlog / News -->
<h2 class="section-title">Bitácora de Desarrollo</h2>
<div class="metrics-grid" style="grid-template-columns: repeat(2, 1fr); margin-bottom: 80px;">
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">EVENTO</span>
            <span style="font-size: 0.8rem; opacity: 0.6;">Indie Game Málaga</span>
        </div>
        <p style="margin: 15px 0;">Presentación oficial del estudio y demo técnica de nuestros sistemas de iluminación.
        </p>
    </div>
    <div class="data-panel">
        <div class="panel-header">
            <span class="panel-label">DEVLOG</span>
            <span style="font-size: 0.8rem; opacity: 0.6;">Sept 2024</span>
        </div>
        <p style="margin: 15px 0;">Inicio del diario de desarrollo. Documentando el proceso de creación de mecánicas de
            sigilo.</p>
    </div>
</div>

<!-- Social Connectivity -->
<div class="contact-section" style="text-align: center;">
    <h3 style="margin-bottom: 30px; font-family: 'Space Grotesk';">Conecta con Verne Games</h3>
    <div class="footer-links" style="justify-content: center; gap: 40px; font-size: 1.5rem;">
        <a href="https://vernegames.com/" target="_blank" aria-label="Website">🌐</a>
        <a href="https://www.instagram.com/vernegames/" target="_blank" aria-label="Instagram">📸</a>
        <a href="https://www.tiktok.com/@vernegamesoficial" target="_blank" aria-label="TikTok">🎵</a>
        <a href="https://www.youtube.com/@vernegames" target="_blank" aria-label="YouTube">▶️</a>
        <a href="https://www.linkedin.com/company/vernegames" target="_blank" aria-label="LinkedIn">💼</a>
        <a href="https://www.facebook.com/vernegames/" target="_blank" aria-label="Facebook">Ef</a>
    </div>
</div>

<?php include '../../Components/footer.php'; ?>