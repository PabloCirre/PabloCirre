<?php
/**
 * Contact Page - Pablo Cirre
 */

$page_title = "Contacto | Desarrollo y Formación - Pablo Cirre";
$page_description = "Contacta para proyectos de Big Data, Desarrollo Web o Formación. Email y WhatsApp directos.";
include '../../Components/header.php';
?>

<div class="container" style="padding-top: 80px; padding-bottom: 80px; max-width: 800px;">
    <h1 class="hero-title">Hablemos.</h1>
    <p class="hero-subtitle">
        ¿Tienes un proyecto técnico o necesitas formación especializada? <br>
        Respondo personalmente en menos de 24h.
    </p>

    <div class="contact-grid" style="display: grid; gap: 30px; margin-top: 50px;">

        <!-- Email Card -->
        <div class="mega-card" style="padding: 30px; border: 1px solid var(--border-color); border-radius: 8px;">
            <h3 style="margin-bottom: 15px; color: var(--accent-color);">Email</h3>
            <p style="margin-bottom: 20px; color: var(--text-secondary);">Para detalles técnicos, presupuestos y
                colaboraciones.</p>
            <a href="mailto:pablo@centraldecomunicacion.es" class="btn-primary" style="display: inline-block;">
                pablo@centraldecomunicacion.es
            </a>
        </div>

        <!-- WhatsApp Card -->
        <div class="mega-card" style="padding: 30px; border: 1px solid var(--border-color); border-radius: 8px;">
            <h3 style="margin-bottom: 15px; color: #25D366;">WhatsApp</h3>
            <p style="margin-bottom: 20px; color: var(--text-secondary);">Consulta rápida o disponibilidad urgente.</p>
            <a href="https://wa.me/34657089081" target="_blank" class="link-secondary"
                style="font-size: 1.1rem; font-weight: bold;">
                WhatsApp: 657 089 081
            </a>
        </div>

    </div>
</div>

<?php include '../../Components/footer.php'; ?>